import requests
import json
import logging

# Loading configuration from a file with UTF-8 encoding | Načítanie konfigurácie zo súboru s UTF-8 kódovaním
with open('config.json', encoding='utf-8') as config_file:
    config = json.load(config_file)

url_main_localization_key = config['url_main_localistation_key']  # Extracting the main URL from the configuration | Extrahovanie hlavného URL z konfigurácie
url_module_localization_key = config['url_modul_localistation_key']  # Extracting the module URL from the configuration | Extrahovanie URL modulu z konfigurácie
modules = config['modules']  # Extracting module names from the configuration | Extrahovanie názvov modulov z konfigurácie

# Setting up logging | Nastavenie logovania
logging.basicConfig(filename='logfile.log', level=logging.INFO)

def download_json(url):
    # Downloads JSON from the given URL | Stiahne JSON z daného URL
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        logging.error(f"Error downloading JSON from the URL: {url}")
        return None

def process_module(url):
    # Processes JSON file for a module | Spracuje JSON súbor pre modul
    data = download_json(url)
    if data:
        return data
    else:
        return {}

def find_duplicates(data):
    # Finds duplicate localization keys | Nájde duplicitné lokalizačné kľúče
    duplicates = {}
    all_keys = {}
    for module, keys in data.items():
        for key in keys:
            if key in all_keys:
                if key not in duplicates:
                    duplicates[key] = [all_keys[key]]
                duplicates[key].append(module)
            else:
                all_keys[key] = module
    return duplicates

def main():
    all_data = {}

    # Processing the main JSON file | Spracovanie hlavného JSON súboru
    main_data = process_module(url_main_localization_key)
    all_data['main'] = main_data

    # Processing JSON files for individual modules | Spracovanie JSON súborov pre jednotlivé moduly
    for module in modules:
        module_url = url_module_localization_key.format(modul=module)
        module_data = process_module(module_url)
        all_data[module] = module_data

    # Saving a file with all localization keys | Uloženie súboru so všetkými lokalizačnými kľúčmi
    with open('all_keys.json', 'w') as f:
        json.dump(all_data, f, indent=4)

    # Finding and saving duplicate localization keys | Nájdenie a uloženie duplicitných lokalizačných kľúčov
    duplicates = find_duplicates(all_data)
    with open('duplicate_keys.json', 'w') as f:
        json.dump(duplicates, f, indent=4)

if __name__ == "__main__":
    main()