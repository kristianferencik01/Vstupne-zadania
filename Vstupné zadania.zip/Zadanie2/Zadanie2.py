from flask import Flask, render_template, request
import requests
import sqlite3
import os
# Initializing Flask application | Inicializácia aplikácie Flask
app = Flask(__name__)

# Function to create SQLite database and insert sample data | Funkcia na vytvorenie SQLite databázy a vloženie ukážkových dát
def create_database():

    os.system('python create_db.py')

# Create SQLite database and insert sample data | Vytvorenie SQLite databázy a vloženie ukážkových dát
create_database()

@app.route('/')
def index():
    # Rendering the index.html template | Vykreslenie šablóny index.html
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    try:
        # Getting the search query from the form | Získanie vyhľadávacieho dotazu zo formulára
        query = request.form['query']
        response = requests.get('https://geodb-cities-api.wirefreethought.com/v1/geo/cities', params={'namePrefix': query})
        response.raise_for_status()
        cities = response.json()
        # Rendering the result.html template with the search results | Vykreslenie šablóny result.html s výsledkami vyhľadávania
        return render_template('result.html', cities=cities)
    except requests.exceptions.RequestException as e:
        # Rendering the error.html template in case of an error | Vykreslenie šablóny error.html v prípade chyby
        return render_template('error.html', error=str(e))

if __name__ == '__main__':
    app.run(debug=True)