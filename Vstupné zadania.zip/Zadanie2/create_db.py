import sqlite3

def create_database():
    # Initialize SQLite database | Inicializácia SQLite databázy
    conn = sqlite3.connect('cities.db')
    cursor = conn.cursor()
    cursor.execute("PRAGMA encoding = 'UTF-8';")

    # Create table to store city information if it doesn't exist | Vytvorenie tabuľky na ukladanie informácií o mestách, ak neexistuje
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS cities (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            country TEXT NOT NULL
        )
    ''')

    # Insert sample data into the cities table | Vloženie ukážkových dát do tabuľky cities
    sample_cities = [
        ('New York', 'United States'),
        ('London', 'United Kingdom'),
        ('Paris', 'France'),
        ('Tokyo', 'Japan')
    ]
    # Executing multiple SQL statements with parameterized queries | Vykonanie viacerých SQL príkazov s parametrickými dotazmi
    cursor.executemany('INSERT INTO cities (name, country) VALUES (?, ?)', sample_cities)
    conn.commit()
    conn.close()
    # Printing a message indicating successful database creation | Vytlačenie správy oznamujúcej úspešné vytvorenie databázy
    print("Database 'cities.db' created and sample data added.")

if __name__ == "__main__":
    create_database()